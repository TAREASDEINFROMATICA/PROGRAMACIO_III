/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package ventana;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.HashMap;
import java.util.Map;

public class nivel3 extends javax.swing.JFrame {
private JButton[][] tablero; // Botones que se mostrarán en la ventana
    private int[][] matrizTablero = {
            {0, 0, 1, 0, 0, 0, 1, 3}, // Gato en (0,7)
            {1, 0, 0, 0, 1, 0, 0, 0},
            {0, 0, 0, 1, 0, 0, 1, 0},
            {0, 1, 0, 1, 0, 0, 1, 1},
            {0, 0, 0, 0, 0, 0, 0, 0},
            {0, 1, 0, 0, 0, 1, 0, 0},
            {0, 0, 0, 0, 1, 0, 0, 0},
            {2, 0, 1, 0, 1, 0, 0, 4} // Ratón en (7,0), salida en (7,7)
    };

    private int ratonX = 7, ratonY = 0;
    private int gatoX = 0, gatoY = 7;
    private boolean turnoRaton = true;
    private Map<String, Integer> memo = new HashMap<>();
    private final int PROFUNDIDAD = 5;
    private boolean jugando = true;
    
    ImageIcon imagenmuro = new ImageIcon(getClass().getResource("/images/muro.png"));
    ImageIcon raton = new ImageIcon(getClass().getResource("/images/raton.png"));
    ImageIcon gato = new ImageIcon(getClass().getResource("/images/gato.png"));
    ImageIcon puerta = new ImageIcon(getClass().getResource("/images/puerta.jpg"));

    public nivel3() {
    setTitle("Gato vs. Ratón PvE");
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    setSize(600, 600);
    setLayout(new BorderLayout());

    crearTablero();
    actualizarTablero();

    addKeyListener(new KeyAdapter() {
        @Override
        public void keyPressed(KeyEvent e) {
            if (turnoRaton) {
                char tecla = e.getKeyChar();
                procesarMovimientoRaton(tecla);
            }
        }
    });

    setFocusable(true);
    requestFocusInWindow();
    setVisible(true);

    JOptionPane.showMessageDialog(this, "¡Inicia el juego! El ratón debe llegar a la salida.");
}

private void procesarMovimientoRaton(char movimiento) {
    int nuevoX = ratonX, nuevoY = ratonY;

    switch (Character.toUpperCase(movimiento)) {
        case 'W': nuevoX--; break;
        case 'S': nuevoX++; break;
        case 'A': nuevoY--; break;
        case 'D': nuevoY++; break;
        default:
            System.out.println("Movimiento no válido. Usa W, A, S o D.");
            return;
    }

    if (esMovimientoValido(nuevoX, nuevoY)) {
        matrizTablero[ratonX][ratonY] = 0; // Limpia la posición actual
        ratonX = nuevoX;
        ratonY = nuevoY;

        if (matrizTablero[ratonX][ratonY] == 4) {
            finalizarJuego("¡El ratón ha llegado a la salida! ¡El Ratón es el ganador!");
            jugando = false;
        } else {
            turnoRaton = false;
            moverGato(); // Turno del gato
        }
    } else {
        JOptionPane.showMessageDialog(null, "Chocaste con un muro.");
    }

    actualizarTablero();
}

    
    

    private void crearTablero() {
        tablero = new JButton[8][8];
        JPanel panelTablero = new JPanel(new GridLayout(8, 8));

        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                tablero[i][j] = new JButton();
                tablero[i][j].setBackground(Color.WHITE);
                panelTablero.add(tablero[i][j]);
            }
        }

        add(panelTablero, BorderLayout.CENTER);
    }

    private void actualizarTablero() {
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                JButton boton = tablero[i][j];
                boton.setText(""); // Limpia cualquier texto previo
                boton.setBackground(Color.WHITE);
                boton.setIcon(null);
                if (matrizTablero[i][j] == 1) { // Obstáculos
                    boton.setIcon(imagenmuro);
                } else if (i == ratonX && j == ratonY) { // Ratón
                    boton.setIcon(raton);
                } else if (i == gatoX && j == gatoY) { // Gato
                    boton.setIcon(gato);
                } else if (matrizTablero[i][j] == 4) { // Salida
                    boton.setIcon(puerta);
                } else { // Espacios vacíos
                    boton.setBackground(Color.WHITE);
                }
            }
        }
    }

    public void iniciarJuego() {
    JOptionPane.showMessageDialog(this, "¡Inicia el juego! El ratón debe llegar a la salida.");
    actualizarTablero();
}



    

    private boolean moverGato() {
    int[] mejorMovimiento = minimax(gatoX, gatoY, ratonX, ratonY, true, PROFUNDIDAD);
    gatoX = mejorMovimiento[1];
    gatoY = mejorMovimiento[2];

    if (gatoX == ratonX && gatoY == ratonY) {
finalizarJuego("¡El gato ha atrapado al ratón!");
        jugando = false;
        return true;
    }

    turnoRaton = true; // Ahora es el turno del ratón
    actualizarTablero();
    return false;
}


    private int[] minimax(int gatoX, int gatoY, int ratonX, int ratonY, boolean turnoGato, int profundidad) {
        if (profundidad == 0) {
            return new int[] {evaluarEstado(gatoX, gatoY, ratonX, ratonY), gatoX, gatoY};
        }

        String estado = gatoX + "," + gatoY + "," + ratonX + "," + ratonY + "," + turnoGato + "," + profundidad;
        if (memo.containsKey(estado)) {
            return new int[] {memo.get(estado), gatoX, gatoY};
        }

        if (gatoX == ratonX && gatoY == ratonY) return new int[] {100, gatoX, gatoY};
        if (ratonX == 7 && ratonY == 7) return new int[] {-100, ratonX, ratonY};

        int mejorValor = turnoGato ? Integer.MIN_VALUE : Integer.MAX_VALUE;
        int[] mejorMovimiento = {mejorValor, gatoX, gatoY};
        int[] movimientos = {-1, 0, 1, 0, 0, -1, 0, 1};

        for (int i = 0; i < movimientos.length; i += 2) {
            int nuevoX = turnoGato ? gatoX + movimientos[i] : ratonX + movimientos[i];
            int nuevoY = turnoGato ? gatoY + movimientos[i + 1] : ratonY + movimientos[i + 1];

            if (esMovimientoValidoGato(nuevoX, nuevoY)) {
                int[] resultado = minimax(
                        turnoGato ? nuevoX : gatoX,
                        turnoGato ? nuevoY : gatoY,
                        turnoGato ? ratonX : nuevoX,
                        turnoGato ? ratonY : nuevoY,
                        !turnoGato,
                        profundidad - 1
                );

                if ((turnoGato && resultado[0] > mejorValor) || (!turnoGato && resultado[0] < mejorValor)) {
                    mejorValor = resultado[0];
                    mejorMovimiento = new int[] {mejorValor, nuevoX, nuevoY};
                }
            }
        }

        memo.put(estado, mejorValor);
        return mejorMovimiento;
    }

    private int evaluarEstado(int gatoX, int gatoY, int ratonX, int ratonY) {
        int distancia = Math.abs(gatoX - ratonX) + Math.abs(gatoY - ratonY);
        return -distancia;
    }

    private boolean esMovimientoValido(int x, int y) {
        return x >= 0 && x < 8 && y >= 0 && y < 8 && matrizTablero[x][y] != 1;
    }
    
    private boolean esMovimientoValidoGato(int x, int y) {
        return x >= 0 && x < 8 && y >= 0 && y < 8 && matrizTablero[x][y] != 1 && matrizTablero[x][y]!=8;
    }
    private void finalizarJuego(String mensaje) {
        JOptionPane.showMessageDialog(this, mensaje);
        jugando = false;
        volverAlInicio();
    }
private void volverAlInicio() {
        JOptionPane.showMessageDialog(this, "Volviendo al menú principal...");
        principal p = new principal(); // Supongo que tienes una clase "Principal" para el menú principal
        p.setVisible(true);
        this.dispose();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 877, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 543, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(nivel3.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(nivel3.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(nivel3.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(nivel3.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new nivel3().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
