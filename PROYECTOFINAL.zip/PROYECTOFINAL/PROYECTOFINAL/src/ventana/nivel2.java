/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package ventana;
import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.Random;
/**
 *
 * @author HP-Ryzen 3
 */
public class nivel2 extends javax.swing.JFrame {

    private JButton[][] tablero; // Representación gráfica del tablero
    private int[][] matrizTablero = { // Representación lógica del tablero
            {0, 0, 1, 0, 0, 0, 1, 3}, // Gato en (0,7)
            {1, 0, 1, 0, 1, 0, 0, 0},
            {0, 0, 0, 1, 0, 1, 0, 0},
            {0, 1, 0, 0, 0, 0, 1, 0},
            {0, 0, 1, 0, 0, 0, 0, 0},
            {0, 0, 1, 1, 0, 1, 0, 0},
            {0, 0, 0, 0, 1, 0, 1, 0},
            {2, 0, 0, 0, 0, 0, 0, 4} // Ratón en (7,0), salida en (7,7)
    };

    private int ratonX = 7, ratonY = 0; // Posición inicial del ratón
    private int gatoX = 0, gatoY = 7;   // Posición inicial del gato
    private boolean turnoRaton = true; // Control de turnos
    private Random random = new Random();
    private boolean jugando = true;
    
    ImageIcon imagenmuro = new ImageIcon(getClass().getResource("/images/muro.png"));
    ImageIcon raton = new ImageIcon(getClass().getResource("/images/raton.png"));
    ImageIcon gato = new ImageIcon(getClass().getResource("/images/gato.png"));
    ImageIcon puerta = new ImageIcon(getClass().getResource("/images/puerta.jpg"));

    
public nivel2() { 
        setTitle("Gato vs. Ratón PvE");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(600, 600);
        setLayout(new BorderLayout());

        crearTablero();
        actualizarTablero();

        setVisible(true);
        iniciarJuego();
    }

    private void crearTablero() {
        tablero = new JButton[8][8];
        JPanel panelTablero = new JPanel(new GridLayout(8, 8));

        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                tablero[i][j] = new JButton();
                tablero[i][j].setBackground(Color.WHITE);
                panelTablero.add(tablero[i][j]);
            }
        }

        add(panelTablero, BorderLayout.CENTER);

        addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (!jugando) return;

                int nuevoX = turnoRaton ? ratonX : gatoX;
                int nuevoY = turnoRaton ? ratonY : gatoY;

                if (turnoRaton) {
                    // Movimiento del ratón con las teclas WASD
                    switch (e.getKeyCode()) {
                        case KeyEvent.VK_W -> nuevoX--; // Movimiento hacia arriba
                        case KeyEvent.VK_S -> nuevoX++; // Movimiento hacia abajo
                        case KeyEvent.VK_A -> nuevoY--; // Movimiento hacia la izquierda
                        case KeyEvent.VK_D -> nuevoY++; // Movimiento hacia la derecha
                        default -> {
                            JOptionPane.showMessageDialog(null, "Tecla no válida. Usa WASD.");
                            return;
                        }
                        
                    }
                    

                    if (esMovimientoValido(nuevoX, nuevoY)) {
                        ratonX = nuevoX;
                        ratonY = nuevoY;
                        actualizarTablero();
                        if (matrizTablero[ratonX][ratonY] == 4) {
                            finalizarJuego("¡El ratón ha llegado a la salida! ¡Ganaste!");
                            jugando = false;
                        }
                    }
                } else {
                    // Movimiento aleatorio del gato
                    moverGatoAleatorio();
                }
                

                turnoRaton = !turnoRaton; // Cambia de turno
            }
        });

        setFocusable(true); // Hacer que el JFrame reciba eventos de teclado
    }

    private void actualizarTablero() {
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                JButton boton = tablero[i][j];
                boton.setText(""); // Limpia cualquier texto previo
                boton.setBackground(Color.WHITE);
                boton.setIcon(null);
                if (matrizTablero[i][j] == 1) { // Obstáculos
                    boton.setIcon(imagenmuro);
                } else if (i == ratonX && j == ratonY) { // Ratón
                    boton.setIcon(raton);
                } else if (i == gatoX && j == gatoY) { // Gato
                    boton.setIcon(gato);
                } else if (matrizTablero[i][j] == 4) { // Salida
                    boton.setIcon(puerta);
                } else { // Espacios vacíos
                    boton.setBackground(Color.WHITE);
                }
            }
        }
    }

    public void iniciarJuego() {
        JOptionPane.showMessageDialog(this, "¡Comienza el juego! El ratón se mueve primero (usa WASD).");
        jugando = true;
    }

    private boolean esMovimientoValido(int x, int y) {
        return x >= 0 && x < 8 && y >= 0 && y < 8 && matrizTablero[x][y] != 1;
    }

    private void moverGatoAleatorio() {
    Random rand = new Random();
    int nuevoX, nuevoY;

    do {
        int direccion = rand.nextInt(4); // 0=arriba, 1=abajo, 2=izquierda, 3=derecha
        nuevoX = gatoX;
        nuevoY = gatoY;

        switch (direccion) {
            case 0 -> nuevoX--;
            case 1 -> nuevoX++;
            case 2 -> nuevoY--;
            case 3 -> nuevoY++;
        }
    } while (!esMovimientoValido(nuevoX, nuevoY)); // Sigue intentando hasta encontrar un movimiento válido

    gatoX = nuevoX;
    gatoY = nuevoY;
    actualizarTablero();

    if (gatoX == ratonX && gatoY == ratonY) {
finalizarJuego("¡El gato ha atrapado al ratón!");
jugando = false;
    }
}
private void finalizarJuego(String mensaje) {
        JOptionPane.showMessageDialog(this, mensaje);
        jugando = false;
        volverAlInicio();
    }
private void volverAlInicio() {
        JOptionPane.showMessageDialog(this, "Volviendo al menú principal...");
        principal p = new principal(); // Supongo que tienes una clase "Principal" para el menú principal
        p.setVisible(true);
        this.dispose();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(nivel2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(nivel2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(nivel2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(nivel2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new nivel2().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
